create view vw_user_facilities(facility_id, district_id, requisition_group_id, user_id, program_id) as
SELECT DISTINCT f.id               AS facility_id,
                f.geographiczoneid AS district_id,
                rg.id              AS requisition_group_id,
                ra.userid          AS user_id,
                ra.programid       AS program_id
FROM facilities f
         JOIN requisition_group_members m ON m.facilityid = f.id
         JOIN requisition_groups rg ON rg.id = m.requisitiongroupid
         JOIN supervisory_nodes sn ON sn.id = rg.supervisorynodeid
         JOIN role_assignments ra ON ra.supervisorynodeid = sn.id OR ra.supervisorynodeid = sn.parentid
         JOIN programs_supported ps ON ps.facilityid = f.id AND ps.programid = ra.programid
WHERE f.active = true;

alter table vw_user_facilities
    owner to postgres;

