create materialized view vw_previous_rnr as
SELECT r.id,
       (SELECT p.id
        FROM requisitions p
        WHERE r.periodid > p.periodid
          AND p.facilityid = r.facilityid
          AND p.programid = r.programid
          AND p.emergency = false
        ORDER BY p.periodid DESC
        LIMIT 1) AS previousrnrid
FROM requisitions r;

alter materialized view vw_previous_rnr owner to postgres;

create index i_previous_rnr_id
    on vw_previous_rnr (id);

