create materialized view vw_last_processing_periods as
SELECT processing_periods.id
FROM processing_periods
ORDER BY processing_periods.id DESC
LIMIT 3;

alter materialized view vw_last_processing_periods owner to postgres;

create unique index idx_lastperiod
    on vw_last_processing_periods (id);

