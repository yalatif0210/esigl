create view vw_z_regions_guinee
            (id, code, name, levelid, parentid, catchmentpopulation, latitude, longitude, createdby, createddate,
             modifiedby, modifieddate)
as
SELECT geographic_zones.id,
       geographic_zones.code,
       geographic_zones.name,
       geographic_zones.levelid,
       geographic_zones.parentid,
       geographic_zones.catchmentpopulation,
       geographic_zones.latitude,
       geographic_zones.longitude,
       geographic_zones.createdby,
       geographic_zones.createddate,
       geographic_zones.modifiedby,
       geographic_zones.modifieddate
FROM geographic_zones
WHERE geographic_zones.levelid = 2;

alter table vw_z_regions_guinee
    owner to postgres;

