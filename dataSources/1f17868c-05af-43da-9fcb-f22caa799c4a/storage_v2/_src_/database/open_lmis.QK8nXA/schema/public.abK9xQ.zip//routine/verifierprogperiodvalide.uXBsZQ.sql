create function verifierprogperiodvalide(programid integer, periodid integer) returns boolean
    language plpgsql
as
$$
DECLARE
programToprocess constant integer :=1;
result BOOLEAN :=false;

begin
if programid <> programToprocess then
 return false;
ELSE
    --select (count(id)>0)::boolean into result  from processing_periods where id=periodid and isorderperiod=true;
    select (count(id)>0)::boolean into result  from vw_last_processingorder_periods where id=periodid;
end if;
return result;
end;
$$;

alter function verifierprogperiodvalide(integer, integer) owner to postgres;

