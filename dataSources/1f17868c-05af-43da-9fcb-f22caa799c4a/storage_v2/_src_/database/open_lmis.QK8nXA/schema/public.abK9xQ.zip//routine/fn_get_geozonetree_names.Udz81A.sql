create function fn_get_geozonetree_names(in_geozone_id integer) returns character varying[]
    language plpgsql
as
$$
BEGIN
RETURN(
SELECT ARRAY
(
WITH RECURSIVE all_geo_zones AS (
SELECT  id, parentid, name
FROM geographic_zones
WHERE id = in_geozone_id
UNION
SELECT gz.id, gz.parentid, gz.name
FROM geographic_zones gz
JOIN all_geo_zones agz
ON (agz.parentid = gz.id)
)
SELECT name FROM all_geo_zones
) AS geo_zone_hierarchy
);
END;
$$;

alter function fn_get_geozonetree_names(integer) owner to postgres;

