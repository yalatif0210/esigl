create function fn_get_stocked_out_notification_details(_tbl_name anyelement, userid integer, programid integer, periodid integer, zoneid integer, productid integer) returns SETOF anyelement
    language plpgsql
as
$$
BEGIN
RETURN QUERY EXECUTE 'SELECT * FROM ' || pg_typeof(_tbl_name) ||
' where programId = '||programId ||' and periodId= '||periodId||' and productId= '||productId||
'and geographiczoneid in (select geographiczoneid from fn_get_user_geographiczone_children('||userId||', '||zoneId||'))';
END
$$;

alter function fn_get_stocked_out_notification_details(anyelement, integer, integer, integer, integer, integer) owner to postgres;

