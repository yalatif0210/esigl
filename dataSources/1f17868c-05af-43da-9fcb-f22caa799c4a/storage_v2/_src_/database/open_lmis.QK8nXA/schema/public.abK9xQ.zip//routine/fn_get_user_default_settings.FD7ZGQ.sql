create function fn_get_user_default_settings(in_programid integer, in_facilityid integer)
    returns TABLE(programid integer, facilityid integer, scheduleid integer, periodid integer, geographiczoneid integer)
    language plpgsql
as
$$
DECLARE
_query VARCHAR;
finalQuery            VARCHAR;
rowrec                 RECORD;
BEGIN
_query := 'SELECT
programid, facilityid, scheduleid, periodid, geographiczoneid
FROM
vw_expected_facilities
WHERE
facilityid = ' || in_facilityid || '
AND programid = ' || in_programid || '
AND periodid IN (
SELECT
MAX (periodid) periodid
FROM
requisitions
WHERE
programid = ' || in_programid || '
AND facilityid = '|| in_facilityid || '
)';
RETURN QUERY EXECUTE _query;
END;
$$;

alter function fn_get_user_default_settings(integer, integer) owner to postgres;

