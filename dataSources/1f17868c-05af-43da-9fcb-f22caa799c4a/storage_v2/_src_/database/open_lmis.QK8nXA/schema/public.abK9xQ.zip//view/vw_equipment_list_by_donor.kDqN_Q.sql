create view vw_equipment_list_by_donor
            (district, facilityname, donor, sourceoffund, equipment_name, model, yearofinstallation, isactive,
             datedecommissioned, replacementrecommended, facility_id, programid, equipment_id, status_id,
             equipmenttype_id, geographiczoneid, ftype_id, district_id, zone_id, region_id, parent, donorid)
as
SELECT geographic_zones.name                 AS district,
       facilities.name                       AS facilityname,
       donors.shortname                      AS donor,
       equipment_inventories.sourceoffund,
       equipments.name                       AS equipment_name,
       equipments.model,
       equipment_inventories.yearofinstallation,
       CASE
           WHEN equipment_inventories.isactive = true THEN 'Yes'::text
           ELSE 'No'::text
           END                               AS isactive,
       CASE
           WHEN equipment_inventories.datedecommissioned IS NULL THEN '-'::text
           ELSE equipment_inventories.datedecommissioned::text
           END                               AS datedecommissioned,
       CASE
           WHEN equipment_inventories.replacementrecommended = false THEN 'No'::text
           ELSE 'Yes'::text
           END                               AS replacementrecommended,
       facilities.id                         AS facility_id,
       programs.id                           AS programid,
       equipments.id                         AS equipment_id,
       equipment_inventory_statuses.statusid AS status_id,
       equipment_types.id                    AS equipmenttype_id,
       facilities.geographiczoneid,
       facilities.typeid                     AS ftype_id,
       vw_districts.district_id,
       vw_districts.zone_id,
       vw_districts.region_id,
       vw_districts.parent,
       donors.id                             AS donorid
FROM equipment_inventories
         JOIN equipments ON equipment_inventories.equipmentid = equipments.id
         JOIN programs ON equipment_inventories.programid = programs.id
         JOIN facilities ON facilities.id = equipment_inventories.facilityid
         JOIN facility_types ON facilities.typeid = facility_types.id
         JOIN geographic_zones ON geographic_zones.id = facilities.geographiczoneid
         JOIN equipment_types ON equipment_types.id = equipments.equipmenttypeid
         LEFT JOIN donors ON donors.id = equipment_inventories.primarydonorid
         JOIN vw_districts ON vw_districts.district_id = facilities.geographiczoneid
         JOIN equipment_inventory_statuses ON equipment_inventory_statuses.inventoryid = equipment_inventories.id
ORDER BY geographic_zones.name, facilities.name, equipments.model;

alter table vw_equipment_list_by_donor
    owner to postgres;

