create view vw_supply_status
            (li_id, li_rnrid, li_productcode, li_product, li_productdisplayorder, li_productcategory,
             li_productcategorydisplayorder, li_dispensingunit, li_beginningbalance, li_quantityreceived,
             li_quantitydispensed, li_stockinhand, li_quantityrequested, li_reasonforrequestedquantity,
             li_calculatedorderquantity, li_quantityapproved, li_totallossesandadjustments, li_newpatientcount,
             li_stockoutdays, li_normalizedconsumption, li_amc, li_maxmonthsofstock, li_maxstockquantity,
             li_packstoship, li_price, li_expirationdate, li_remarks, li_dosespermonth, li_dosesperdispensingunit,
             li_packsize, li_roundtozero, li_packroundingthreshold, li_fullsupply, li_createdby, li_createddate,
             li_modifiedby, li_modifieddate, pg_id, pg_code, pg_name, p_id, p_code, p_primaryname, p_displayorder,
             indicator_product, p_description, facility_type_name, ft_id, ft_code, ft_nominalmaxmonth, ft_nominaleop,
             f_id, f_code, facility, supplyingfacility, f_zoneid, fp_maxmonthsofstock, fp_minmonthsofstock, fp_eop,
             r_status, supervisorynodeid, ps_id, pp_id, geographiczoneid, geographiczonename)
as
SELECT requisition_line_items.id                                      AS li_id,
       requisition_line_items.rnrid                                   AS li_rnrid,
       requisition_line_items.productcode                             AS li_productcode,
       requisition_line_items.product                                 AS li_product,
       requisition_line_items.productdisplayorder                     AS li_productdisplayorder,
       requisition_line_items.productcategory                         AS li_productcategory,
       requisition_line_items.productcategorydisplayorder             AS li_productcategorydisplayorder,
       requisition_line_items.dispensingunit                          AS li_dispensingunit,
       requisition_line_items.beginningbalance                        AS li_beginningbalance,
       requisition_line_items.quantityreceived                        AS li_quantityreceived,
       requisition_line_items.quantitydispensed                       AS li_quantitydispensed,
       requisition_line_items.stockinhand                             AS li_stockinhand,
       requisition_line_items.quantityrequested                       AS li_quantityrequested,
       requisition_line_items.reasonforrequestedquantity              AS li_reasonforrequestedquantity,
       requisition_line_items.calculatedorderquantity                 AS li_calculatedorderquantity,
       requisition_line_items.quantityapproved                        AS li_quantityapproved,
       requisition_line_items.totallossesandadjustments               AS li_totallossesandadjustments,
       requisition_line_items.newpatientcount                         AS li_newpatientcount,
       requisition_line_items.stockoutdays                            AS li_stockoutdays,
       requisition_line_items.normalizedconsumption                   AS li_normalizedconsumption,
       requisition_line_items.amc                                     AS li_amc,
       requisition_line_items.maxmonthsofstock                        AS li_maxmonthsofstock,
       requisition_line_items.maxstockquantity                        AS li_maxstockquantity,
       requisition_line_items.packstoship                             AS li_packstoship,
       requisition_line_items.price                                   AS li_price,
       requisition_line_items.expirationdate                          AS li_expirationdate,
       requisition_line_items.remarks                                 AS li_remarks,
       requisition_line_items.dosespermonth                           AS li_dosespermonth,
       requisition_line_items.dosesperdispensingunit                  AS li_dosesperdispensingunit,
       requisition_line_items.packsize                                AS li_packsize,
       requisition_line_items.roundtozero                             AS li_roundtozero,
       requisition_line_items.packroundingthreshold                   AS li_packroundingthreshold,
       requisition_line_items.fullsupply                              AS li_fullsupply,
       requisition_line_items.createdby                               AS li_createdby,
       requisition_line_items.createddate                             AS li_createddate,
       requisition_line_items.modifiedby                              AS li_modifiedby,
       requisition_line_items.modifieddate                            AS li_modifieddate,
       programs.id                                                    AS pg_id,
       programs.code                                                  AS pg_code,
       programs.name                                                  AS pg_name,
       products.id                                                    AS p_id,
       products.code                                                  AS p_code,
       products.primaryname                                           AS p_primaryname,
       program_products.displayorder                                  AS p_displayorder,
       products.tracer                                                AS indicator_product,
       products.description                                           AS p_description,
       facility_types.name                                            AS facility_type_name,
       facility_types.id                                              AS ft_id,
       facility_types.code                                            AS ft_code,
       facility_types.nominalmaxmonth                                 AS ft_nominalmaxmonth,
       facility_types.nominaleop                                      AS ft_nominaleop,
       facilities.id                                                  AS f_id,
       facilities.code                                                AS f_code,
       facilities.name                                                AS facility,
       fn_get_supplying_facility_name(requisitions.supervisorynodeid) AS supplyingfacility,
       facilities.geographiczoneid                                    AS f_zoneid,
       facility_approved_products.maxmonthsofstock                    AS fp_maxmonthsofstock,
       facility_approved_products.minmonthsofstock                    AS fp_minmonthsofstock,
       facility_approved_products.eop                                 AS fp_eop,
       requisitions.status                                            AS r_status,
       requisitions.supervisorynodeid,
       processing_schedules.id                                        AS ps_id,
       processing_periods.id                                          AS pp_id,
       geographic_zones.id                                            AS geographiczoneid,
       geographic_zones.name                                          AS geographiczonename
FROM requisition_line_items
         JOIN requisitions ON requisitions.id = requisition_line_items.rnrid
         JOIN facilities ON facilities.id = requisitions.facilityid
         JOIN facility_types ON facility_types.id = facilities.typeid
         JOIN processing_periods ON processing_periods.id = requisitions.periodid
         JOIN processing_schedules ON processing_schedules.id = processing_periods.scheduleid
         JOIN products ON products.code::text = requisition_line_items.productcode::text
         JOIN program_products
              ON requisitions.programid = program_products.programid AND products.id = program_products.productid
         JOIN product_categories ON product_categories.id = program_products.productcategoryid
         JOIN programs ON programs.id = requisitions.programid
         JOIN geographic_zones ON geographic_zones.id = facilities.geographiczoneid
         JOIN facility_approved_products ON facility_types.id = facility_approved_products.facilitytypeid AND
                                            facility_approved_products.programproductid = program_products.id;

alter table vw_supply_status
    owner to postgres;

