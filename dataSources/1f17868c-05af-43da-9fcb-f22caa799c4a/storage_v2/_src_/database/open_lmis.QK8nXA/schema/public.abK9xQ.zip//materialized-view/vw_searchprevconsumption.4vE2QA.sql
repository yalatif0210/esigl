create materialized view vw_searchprevconsumption as
SELECT req.facilityid,
       req.periodid,
       reql.productcode,
       reql.quantitydispensed
FROM requisition_line_items reql
         JOIN requisitions req ON reql.rnrid = req.id
WHERE req.periodid >= 120
  AND req.periodid <= 122
  AND req.programid = 1
  AND reql.skipped = false
  AND req.status::text <> 'INITIATED'::text
  AND req.status::text <> 'SUBMITTED'::text
UNION
SELECT req.facilityid,
       req.periodid,
       reql.productcode,
       reql.quantitydispensed
FROM requisition_line_items reql
         JOIN requisitions req ON reql.rnrid = req.id
WHERE req.periodid >= 130
  AND req.periodid <= 131
  AND req.programid = 1
  AND reql.skipped = false
  AND req.status::text <> 'INITIATED'::text
  AND req.status::text <> 'SUBMITTED'::text;

alter materialized view vw_searchprevconsumption owner to postgres;

create unique index idx_searchprevconsumption
    on vw_searchprevconsumption (periodid, productcode, facilityid);

