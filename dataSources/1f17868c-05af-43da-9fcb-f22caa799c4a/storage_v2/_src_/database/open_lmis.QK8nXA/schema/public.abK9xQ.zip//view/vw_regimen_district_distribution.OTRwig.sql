create view vw_regimen_district_distribution
            (programid, scheduleid, periodid, categoryid, regimenid, regimen, patientsontreatment,
             patientstoinitiatetreatment, patientsstoppedtreatment, facilityid, status, facilityname, facilitycode,
             facilitytypeid, facilitytype, district, districtid, regionid, region, zoneid, zone, parent)
as
SELECT r.programid,
       rgps.scheduleid,
       pp.id           AS periodid,
       regimens.categoryid,
       regimens.id     AS regimenid,
       li.name         AS regimen,
       li.patientsontreatment,
       li.patientstoinitiatetreatment,
       li.patientsstoppedtreatment,
       r.facilityid,
       r.status,
       f.name          AS facilityname,
       f.code          AS facilitycode,
       f.typeid        AS facilitytypeid,
       ft.name         AS facilitytype,
       d.district_name AS district,
       d.district_id   AS districtid,
       d.region_id     AS regionid,
       d.region_name   AS region,
       d.zone_id       AS zoneid,
       d.zone_name     AS zone,
       d.parent
FROM regimen_line_items li
         JOIN requisitions r ON li.rnrid = r.id
         JOIN facilities f ON r.facilityid = f.id
         JOIN facility_types ft ON f.typeid = ft.id
         JOIN vw_districts d ON f.geographiczoneid = d.district_id
         JOIN requisition_group_members rgm ON r.facilityid = rgm.facilityid
         JOIN programs_supported ps ON r.programid = ps.programid AND r.facilityid = ps.facilityid
         JOIN regimens ON li.code::text = regimens.code::text
         JOIN processing_periods pp ON r.periodid = pp.id
         JOIN requisition_group_program_schedules rgps
              ON rgm.requisitiongroupid = rgps.requisitiongroupid AND pp.scheduleid = rgps.scheduleid;

alter table vw_regimen_district_distribution
    owner to postgres;

