create view vw_vaccine_requisitions
            (parent, zoneid, zone_name, regionid, region_name, districtid, district_name, orderid, programid, startdate,
             enddate, period_name, scheduleid, orderdate, statusdate, emergency, isverified, status, current_status)
as
SELECT vd.parent,
       vd.zone_id           AS zoneid,
       vd.zone_name,
       vd.region_id         AS regionid,
       vd.region_name,
       vd.district_id       AS districtid,
       vd.district_name,
       vr.id                AS orderid,
       vr.programid,
       pp.startdate,
       pp.enddate,
       pp.name              AS period_name,
       pp.scheduleid,
       vr.orderdate::date   AS orderdate,
       vs.createddate::date AS statusdate,
       vr.emergency,
       vr.isverified,
       vs.status,
       vr.status            AS current_status
FROM vaccine_order_requisitions vr
         JOIN facilities f ON vr.facilityid = f.id
         JOIN vw_districts vd ON vd.district_id = f.geographiczoneid
         JOIN vaccine_order_requisition_status_changes vs ON vr.id = vs.orderid
         JOIN processing_periods pp ON vr.periodid = pp.id
WHERE vs.status::text = ANY (ARRAY ['SUBMITTED'::character varying::text, 'ISSUED'::character varying::text]);

alter table vw_vaccine_requisitions
    owner to postgres;

