create function fn_update_program_product_isa(program_product_id integer, isa_coefficient_id integer, who_ratio numeric, doses_per_year integer, wastage_factor numeric, buffer_percentage numeric, minimum_value integer, maximum_value integer, adjustment_value integer, created_by integer, created_date timestamp without time zone, modified_by integer, modified_date timestamp without time zone, population_source integer) returns void
    language plpgsql
as
$$
BEGIN
UPDATE isa_coefficients
SET whoratio = who_ratio,
dosesperyear = doses_per_year,
wastagefactor = wastage_factor,
bufferpercentage = buffer_percentage,
minimumvalue = minimum_value,
maximumvalue = maximum_value,
adjustmentvalue = adjustment_value,
createdby = created_by,
createddate = created_date,
modifiedby = modified_by,
modifieddate = modified_date,
populationsource =  population_source
WHERE
id = isa_coefficient_id;
UPDATE program_products
SET isaCoefficientsId = isa_coefficient_id
WHERE id = program_product_id;
END;
$$;

alter function fn_update_program_product_isa(integer, integer, numeric, integer, numeric, numeric, integer, integer, integer, integer, timestamp, integer, timestamp, integer) owner to postgres;

