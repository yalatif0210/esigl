create view vw_order_fill_rate
            (status, facilityid, periodid, product, productcode, facilityname, scheduleid, facilitytypeid, productid,
             productcategoryid, programid, zoneid, zonename, quantityapproved, quantityreceived, totalproductsapproved,
             totalproductsreceived, totalproductspushed)
as
SELECT r.status,
       r.facilityid,
       r.periodid,
       li.product,
       li.productcode,
       f.name                       AS facilityname,
       pr.scheduleid,
       f.typeid                     AS facilitytypeid,
       p.id                         AS productid,
       pp.productcategoryid,
       r.programid,
       f.geographiczoneid           AS zoneid,
       gz.name                      AS zonename,
       li.quantityapproved::numeric AS quantityapproved,
       sli.quantityshipped::numeric AS quantityreceived,
       li.quantityapproved::numeric AS totalproductsapproved,
       sli.quantityshipped::numeric AS totalproductsreceived,
       sli.quantityshipped::numeric AS totalproductspushed
FROM requisitions r
         JOIN processing_periods pr ON pr.id = r.periodid
         JOIN facilities f ON f.id = r.facilityid
         JOIN geographic_zones gz ON gz.id = f.geographiczoneid
         JOIN requisition_line_items li ON li.rnrid = r.id
         JOIN products p ON p.code::text = li.productcode::text
         JOIN program_products pp ON p.id = pp.productid AND pp.programid = r.programid
         JOIN orders o ON o.id = r.id
         LEFT JOIN shipment_line_items sli ON o.id = sli.orderid AND li.productcode::text = sli.productcode::text;

alter table vw_order_fill_rate
    owner to postgres;

