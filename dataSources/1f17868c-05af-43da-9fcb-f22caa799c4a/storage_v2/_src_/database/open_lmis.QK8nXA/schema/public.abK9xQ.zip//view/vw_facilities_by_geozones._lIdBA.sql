create view vw_facilities_by_geozones(facility_id, facility_code, facility_name, "Type", region, district) as
SELECT f.id      AS facility_id,
       f.code    AS facility_code,
       f.name    AS facility_name,
       ft.name   AS "Type",
       reg.name  AS region,
       pref.name AS district
FROM facilities f
         JOIN geographic_zones pref ON pref.id = f.geographiczoneid
         JOIN geographic_zones reg ON reg.id = pref.parentid
         JOIN facility_types ft ON ft.id = f.typeid
WHERE f.enabled = true
  AND f.active = true
ORDER BY reg.name, pref.name;

alter table vw_facilities_by_geozones
    owner to postgres;

