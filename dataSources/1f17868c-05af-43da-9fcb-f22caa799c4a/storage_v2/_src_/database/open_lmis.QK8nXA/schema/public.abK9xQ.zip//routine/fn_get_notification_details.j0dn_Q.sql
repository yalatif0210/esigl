create function fn_get_notification_details(_tbl_name anyelement, id integer) returns SETOF anyelement
    language plpgsql
as
$$
BEGIN
RETURN QUERY EXECUTE 'SELECT * FROM ' || pg_typeof(_tbl_name) || ' where alertsummaryid = '||id;
END
$$;

alter function fn_get_notification_details(anyelement, integer) owner to postgres;

