create view vw_rnr_status (programname, programid, periodid, facilityid, rnrid, status, geographiczonename) as
SELECT p.name  AS programname,
       r.programid,
       r.periodid,
       f.id    AS facilityid,
       r.id    AS rnrid,
       r.status,
       gz.name AS geographiczonename
FROM facilities f
         JOIN requisitions r ON r.facilityid = f.id
         JOIN programs p ON p.id = r.programid
         JOIN requisition_status_changes ON r.id = requisition_status_changes.rnrid
         JOIN geographic_zones gz ON gz.id = f.geographiczoneid;

alter table vw_rnr_status
    owner to postgres;

