create function fn_previous_cb(v_rnr_id integer, v_productcode character varying) returns integer
    language plpgsql
as
$$
DECLARE
v_ret integer;
v_prev_id integer;
BEGIN
select stockinhand  into v_ret from requisition_line_items where id < v_rnr_id and productcode = v_productcode;
v_ret = COALESCE(v_ret,0);
return v_ret;
END;
$$;

alter function fn_previous_cb(integer, varchar) owner to postgres;

