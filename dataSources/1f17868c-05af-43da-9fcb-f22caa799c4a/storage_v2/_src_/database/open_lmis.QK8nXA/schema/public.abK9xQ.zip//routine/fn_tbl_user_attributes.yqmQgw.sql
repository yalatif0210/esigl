create function fn_tbl_user_attributes(in_user_id integer DEFAULT NULL::integer, in_user_name character varying DEFAULT NULL::character varying, in_program_id integer DEFAULT NULL::integer, in_output text DEFAULT NULL::text) returns text
    language plpgsql
as
$$
DECLARE
rg_cursor CURSOR FOR
SELECT distinct on (user_id,rg_id) user_id, rg_id, rg_code, role_id
FROM vw_user_role_program_rg
where (user_id = in_user_id or in_user_id is null)
and (username = in_user_name or in_user_name is null)
and (program_id = in_program_id or in_program_id is null);
fac_cursor CURSOR FOR
SELECT distinct on (user_id,facility_id) user_id, facility_id, facility_code, role_id
FROM vw_user_program_facilities
where (user_id = in_user_id or in_user_id is null)
and (username = in_user_name or in_user_name is null)
and (program_id = in_program_id or in_program_id is null);
user_cursor CURSOR FOR
SELECT role_assignments.roleid
FROM  users
INNER JOIN role_assignments ON role_assignments.userid = users.id
where (users.id = in_user_id or in_user_id is null)
and (users.username = in_user_name or in_user_name is null)
and role_assignments.roleid = 1;
rec RECORD;
delim character(1);
ret_val TEXT;
BEGIN
delim = '';
ret_val = '';
open user_cursor;
FETCH user_cursor INTO rec;
IF FOUND THEN
ret_val = '*';
RETURN ret_val;
end if;
close user_cursor;
IF upper(in_output) = 'FACCODE' OR upper(in_output) = 'FACID' THEN
OPEN fac_cursor;
LOOP
FETCH fac_cursor INTO rec;
EXIT WHEN NOT FOUND;
if upper(in_output) = 'FACID' THEN
ret_val = ret_val || delim ||rec.facility_id;
elsif upper(in_output) = 'FACCODe' THEN
ret_val = ret_val || delim ||chr(39)||rec.facility_code||chr(39);
else
ret_val = '';
END IF;
delim = ',';
END LOOP;
CLOSE fac_cursor;
ELSIF upper(in_output) = 'RGID' OR upper(in_output) = 'RGCODE' OR upper(in_output) = 'SNODE' THEN
OPEN rg_cursor;
LOOP
FETCH rg_cursor INTO rec;
EXIT WHEN NOT FOUND;
if upper(in_output) = 'RGID' THEN
ret_val = ret_val || delim ||rec.rg_id;
elsif upper(in_output) = 'RGCODE' THEN
ret_val = ret_val || delim ||chr(39)||rec.rg_code||chr(39);
elsif upper(in_output) = 'SNODE' THEN
ret_val = ret_val || delim ||rec.supervisorynodeid;
else
ret_val = '';
END IF;
delim = ',';
END LOOP;
CLOSE rg_cursor;
END IF;
ret_val = coalesce(ret_val, 'none');
RETURN ret_val;
EXCEPTION WHEN OTHERS THEN RETURN SQLERRM;
END;
$$;

alter function fn_tbl_user_attributes(integer, varchar, integer, text) owner to postgres;

