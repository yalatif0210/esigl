create view vw_stock_cards
            (id, facilityid, productid, totalquantityonhand, effectivedate, notes, createdby, createddate, modifiedby,
             modifieddate, program_product_id, programid, maxmonthsofstock, minmonthsofstock, eop, whoratio,
             dosesperyear, wastagefactor, bufferpercentage, minimumvalue, maximumvalue, adjustmentvalue)
as
SELECT DISTINCT sc.id,
                sc.facilityid,
                sc.productid,
                sc.totalquantityonhand,
                sc.effectivedate,
                sc.notes,
                sc.createdby,
                sc.createddate,
                sc.modifiedby,
                sc.modifieddate,
                pp.id AS program_product_id,
                pp.programid,
                fap.maxmonthsofstock,
                fap.minmonthsofstock,
                fap.eop,
                ic.whoratio,
                ic.dosesperyear,
                ic.wastagefactor,
                ic.bufferpercentage,
                ic.minimumvalue,
                ic.maximumvalue,
                ic.adjustmentvalue
FROM stock_cards sc
         LEFT JOIN program_products pp ON sc.productid = pp.productid
         LEFT JOIN facilities ON sc.facilityid = facilities.id
         LEFT JOIN isa_coefficients ic ON ic.id = pp.isacoefficientsid
         LEFT JOIN facility_approved_products fap
                   ON facilities.typeid = fap.facilitytypeid AND fap.programproductid = pp.id;

alter table vw_stock_cards
    owner to postgres;

