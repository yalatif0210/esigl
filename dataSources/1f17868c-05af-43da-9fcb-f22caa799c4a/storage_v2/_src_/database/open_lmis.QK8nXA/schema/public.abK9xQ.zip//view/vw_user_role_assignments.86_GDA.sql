create view vw_user_role_assignments
            (firstname, lastname, email, cellphone, officephone, supervisorynodename, programname, rolename, programid,
             supervisorynodeid, roleid)
as
SELECT users.firstname,
       users.lastname,
       users.email,
       users.cellphone,
       users.officephone,
       supervisory_nodes.name AS supervisorynodename,
       programs.name          AS programname,
       roles.name             AS rolename,
       programs.id            AS programid,
       supervisory_nodes.id   AS supervisorynodeid,
       roles.id               AS roleid
FROM roles
         LEFT JOIN role_assignments ON roles.id = role_assignments.roleid
         LEFT JOIN programs ON programs.id = role_assignments.programid
         LEFT JOIN supervisory_nodes ON supervisory_nodes.id = role_assignments.supervisorynodeid
         LEFT JOIN users ON users.id = role_assignments.userid;

alter table vw_user_role_assignments
    owner to postgres;

