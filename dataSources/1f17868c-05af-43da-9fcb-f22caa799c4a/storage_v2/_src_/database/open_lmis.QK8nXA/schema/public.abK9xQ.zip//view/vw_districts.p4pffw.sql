create view vw_districts (district_id, district_name, region_id, region_name, zone_id, zone_name, parent) as
SELECT d.id       AS district_id,
       d.name     AS district_name,
       r.id       AS region_id,
       r.name     AS region_name,
       z.id       AS zone_id,
       z.name     AS zone_name,
       z.parentid AS parent
FROM geographic_zones d
         JOIN geographic_zones r ON d.parentid = r.id
         JOIN geographic_zones z ON z.id = r.parentid;

alter table vw_districts
    owner to postgres;

