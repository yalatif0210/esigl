create function get_vaccine_coverage_denominator_name(in_program integer, in_facility integer, in_year integer, in_product integer, in_dose integer) returns character varying
    language plpgsql
as
$$
DECLARE
v_denominator VARCHAR (20);
BEGIN
select dc.name into v_denominator
from vaccine_product_doses d
inner join demographic_estimate_categories dc on d.denominatorestimatecategoryid=dc.id
where programid = in_program
and productid = in_product
and (doseid = in_dose or 0=in_dose);
return v_denominator;
END;
$$;

alter function get_vaccine_coverage_denominator_name(integer, integer, integer, integer, integer) owner to postgres;

