create view vw_vaccine_cold_chain
            (period_id, period_name, period_start_date, period_end_date, geographic_zone_id, geographic_zone_name,
             level_id, parent_id, facility_id, facility_code, facility_name, facility_type_name, report_id, programid,
             reported_date, equipment_name, model, yearofinstallation, equipment_type_name, mintemp, maxtemp,
             minepisodetemp, maxepisodetemp, energy_source, status, serialnumber)
as
SELECT pp.id          AS period_id,
       pp.name        AS period_name,
       pp.startdate   AS period_start_date,
       pp.enddate     AS period_end_date,
       gz.id          AS geographic_zone_id,
       gz.name        AS geographic_zone_name,
       gz.levelid     AS level_id,
       gz.parentid    AS parent_id,
       f.id           AS facility_id,
       f.code         AS facility_code,
       f.name         AS facility_name,
       ft.name        AS facility_type_name,
       vr.id          AS report_id,
       vr.programid,
       vr.createddate AS reported_date,
       e.name         AS equipment_name,
       e.model,
       ei.yearofinstallation,
       et.name        AS equipment_type_name,
       ccli.mintemp,
       ccli.maxtemp,
       ccli.minepisodetemp,
       ccli.maxepisodetemp,
       eet.name       AS energy_source,
       es.name        AS status,
       ei.serialnumber
FROM vaccine_report_cold_chain_line_items ccli
         JOIN vaccine_reports vr ON vr.id = ccli.reportid
         JOIN facilities f ON vr.facilityid = f.id
         JOIN facility_types ft ON f.typeid = ft.id
         JOIN geographic_zones gz ON f.geographiczoneid = gz.id
         JOIN processing_periods pp ON vr.periodid = pp.id
         JOIN equipment_inventories ei ON ei.facilityid = f.id AND ccli.equipmentinventoryid = ei.id
         JOIN equipments e ON ei.equipmentid = e.id
         JOIN equipment_types et ON e.equipmenttypeid = et.id
         LEFT JOIN equipment_energy_types eet ON e.energytypeid = eet.id
         LEFT JOIN equipment_operational_status es ON es.id = ccli.operationalstatusid;

alter table vw_vaccine_cold_chain
    owner to postgres;

