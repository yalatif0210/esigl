create view vw_facility_requisitions
            (facilityid, facilitycode, facilityname, rnrid, periodid, status, geographiczoneid, enabled, sdp, typeid,
             programid, emergency, createddate, geographiczonename)
as
SELECT facilities.id         AS facilityid,
       facilities.code       AS facilitycode,
       facilities.name       AS facilityname,
       requisitions.id       AS rnrid,
       requisitions.periodid,
       requisitions.status,
       facilities.geographiczoneid,
       facilities.enabled,
       facilities.sdp,
       facilities.typeid,
       requisitions.programid,
       requisitions.emergency,
       requisitions.createddate,
       geographic_zones.name AS geographiczonename
FROM requisitions
         JOIN facilities ON facilities.id = requisitions.facilityid
         JOIN geographic_zones ON geographic_zones.id = facilities.geographiczoneid;

alter table vw_facility_requisitions
    owner to postgres;

