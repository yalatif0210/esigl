create view vw_user_geographic_zones(userid, supervisorynodeid, geographiczoneid, levelid, programid) as
SELECT DISTINCT ra.userid,
                ra.supervisorynodeid,
                gz.id AS geographiczoneid,
                gz.levelid,
                ra.programid
FROM facilities f
         JOIN geographic_zones gz ON gz.id = f.geographiczoneid
         JOIN requisition_group_members m ON m.facilityid = f.id
         JOIN requisition_groups rg ON rg.id = m.requisitiongroupid
         JOIN supervisory_nodes sn ON sn.id = rg.supervisorynodeid
         JOIN role_assignments ra ON ra.supervisorynodeid = sn.id OR ra.supervisorynodeid = sn.parentid
         JOIN geographic_zones d ON d.id = f.geographiczoneid
WHERE ra.supervisorynodeid IS NOT NULL
  AND rg.supervisorynodeid IS NOT NULL;

alter table vw_user_geographic_zones
    owner to postgres;

