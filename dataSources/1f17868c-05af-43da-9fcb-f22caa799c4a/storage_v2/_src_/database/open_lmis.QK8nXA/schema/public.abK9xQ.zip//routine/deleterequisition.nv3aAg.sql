create function deleterequisition(requisitionid integer) returns boolean
    language plpgsql
as
$$
DECLARE
resultops integer :=null;
BEGIN
--first delete the requisition_line_item_losses_adjustments
-- Get the requisitionlineitems ids

delete from requisition_line_item_losses_adjustments 
where requisitionlineitemid in (
    select id from requisition_line_items where rnrid= requisitionid
);
GET DIAGNOSTICS resultops := ROW_COUNT;
raise info 'losses and adjustments: % deleted',resultops;

-- now delete the associated requisition_line_items
resultops :=null;
 delete from requisition_line_items where rnrid=requisitionid;
 GET DIAGNOSTICS resultops := ROW_COUNT;
    raise info 'requisition_line_items: % deleted',resultops;

-- now delete the associated requisition_status_changes
resultops :=null;
 delete from requisition_status_changes where rnrid=requisitionid;
 GET DIAGNOSTICS resultops := ROW_COUNT;
    raise info 'requisition_status_changes: % deleted',resultops;

-- now delete the associated comments
resultops :=null;
 delete from comments where rnrid=requisitionid;
 GET DIAGNOSTICS resultops := ROW_COUNT;
 raise info 'comments: % deleted',resultops;

-- now delete the associated requisitions
resultops :=null;
 delete from requisitions where id=requisitionid;
 GET DIAGNOSTICS resultops := ROW_COUNT;
    raise info 'requisitions: % deleted',resultops;

return true;
END
$$;

alter function deleterequisition(integer) owner to postgres;

