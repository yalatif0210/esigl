create view vw_requisition_detail
            (program_id, program_name, product_id, product_code, product_primaryname, product_description,
             indicator_product, processing_periods_id, processing_periods_name, processing_periods_start_date,
             processing_periods_end_date, processing_schedules_id, facility_type_id, facility_type_name, facility_code,
             facility_name, productcode, product, beginningbalance, quantityreceived, quantitydispensed, stockinhand,
             quantityrequested, calculatedorderquantity, quantityapproved, totallossesandadjustments, newpatientcount,
             stockoutdays, normalizedconsumption, amc, maxmonthsofstock, maxstockquantity, packstoship, packsize,
             fullsupply, facility_id, req_id, req_status, req_line_id, zone_id, region, nominalmaxmonth, nominaleop,
             du_code, pf_code, dispensingunit, categoryid, productgroupid, scheduleid, emergency)
as
SELECT programs.id                        AS program_id,
       programs.name                      AS program_name,
       products.id                        AS product_id,
       products.code                      AS product_code,
       products.primaryname               AS product_primaryname,
       products.description               AS product_description,
       products.tracer                    AS indicator_product,
       processing_periods.id              AS processing_periods_id,
       processing_periods.name            AS processing_periods_name,
       processing_periods.startdate       AS processing_periods_start_date,
       processing_periods.enddate         AS processing_periods_end_date,
       processing_periods.scheduleid      AS processing_schedules_id,
       facility_types.id                  AS facility_type_id,
       facility_types.name                AS facility_type_name,
       facilities.code                    AS facility_code,
       facilities.name                    AS facility_name,
       requisition_line_items.productcode,
       requisition_line_items.product,
       requisition_line_items.beginningbalance,
       requisition_line_items.quantityreceived,
       requisition_line_items.quantitydispensed,
       requisition_line_items.stockinhand,
       requisition_line_items.quantityrequested,
       requisition_line_items.calculatedorderquantity,
       requisition_line_items.quantityapproved,
       requisition_line_items.totallossesandadjustments,
       requisition_line_items.newpatientcount,
       requisition_line_items.stockoutdays,
       requisition_line_items.normalizedconsumption,
       requisition_line_items.amc,
       requisition_line_items.maxmonthsofstock,
       requisition_line_items.maxstockquantity,
       requisition_line_items.packstoship,
       requisition_line_items.packsize,
       requisition_line_items.fullsupply,
       facilities.id                      AS facility_id,
       requisitions.id                    AS req_id,
       requisitions.status                AS req_status,
       requisition_line_items.id          AS req_line_id,
       geographic_zones.id                AS zone_id,
       geographic_zones.name              AS region,
       facility_types.nominalmaxmonth,
       facility_types.nominaleop,
       dosage_units.code                  AS du_code,
       product_forms.code                 AS pf_code,
       products.dispensingunit,
       program_products.productcategoryid AS categoryid,
       products.productgroupid,
       processing_periods.scheduleid,
       requisitions.emergency
FROM requisition_line_items
         JOIN requisitions ON requisition_line_items.rnrid = requisitions.id
         JOIN products ON requisition_line_items.productcode::text = products.code::text
         JOIN programs ON requisitions.programid = programs.id
         JOIN program_products ON products.id = program_products.productid AND program_products.programid = programs.id
         JOIN processing_periods ON requisitions.periodid = processing_periods.id
         JOIN product_categories ON program_products.productcategoryid = product_categories.id
         JOIN processing_schedules ON processing_periods.scheduleid = processing_schedules.id
         JOIN facilities ON requisitions.facilityid = facilities.id
         JOIN facility_types ON facilities.typeid = facility_types.id
         JOIN geographic_zones ON facilities.geographiczoneid = geographic_zones.id
         JOIN product_forms ON products.formid = product_forms.id
         JOIN dosage_units ON products.dosageunitid = dosage_units.id;

alter table vw_requisition_detail
    owner to postgres;

