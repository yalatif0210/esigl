create function fn_get_program_product_id(v_program integer, v_product integer) returns integer
    language plpgsql
as
$$
DECLARE
v_ret integer;
BEGIN
SELECT id into v_ret FROM program_products where programid = v_program and productid = v_product;
return v_ret;
END;
$$;

alter function fn_get_program_product_id(integer, integer) owner to postgres;

