create function updatecalculatedquantity() returns trigger
    language plpgsql
as
$$
DECLARE
iterate int :=0;
listperiodsource  varchar :=null;
_programid int :=0;
_periodid int :=0;
_facilityid int :=0;
sumqty int :=0;
rescheck BOOLEAN :=false;
resrow record;
nbdaysinquater constant DECIMAL :=91.5;
correctionfactor  decimal:=0;
calculatedamc int :=0;
ajustedquantitytoorder int :=0;
querystatement VARCHAR:='';
_periods2process VARCHAR :='';
_factor float:=0;
BEGIN
    --Not process this during command approval
    if (NEW.quantityrequested is not null) or (OLD.quantityrequested is not null)THEN
        return NEW;
    end if;
    if NEW.stockinhand is null THEN
        --raise log   'Stockinhand is null for product %', NEW.productcode;
        return NEW;
    end if;
    raise log  'Step 1: passed: %',NEW.stockinhand::int;
    /*
    for  resrow in  EXECUTE 'select id from processing_periods order by id desc limit 2 offset 1' loop
        case 
            when iterate=0 then listperiodsource:= concat(resrow.id,',') ;
            else listperiodsource:=concat(listperiodsource,resrow.id);
            end case;
        iterate:= iterate+1;
    end loop;
    */
    resrow:=null;
    DROP TABLE IF EXISTS programperiodids;
    create temp TABLE programperiodids
    (
        programid int,
        periodid int,
        facilityid int

    );
    
    insert into programperiodids
    select programid ,periodid,facilityid from  requisitions where id=NEW.rnrid and programid=1;

    for  resrow in  EXECUTE 'select * from programperiodids ' loop
        _programid:=resrow.programid;
        _periodid:=resrow.periodid;
        _facilityid=resrow.facilityid;
    end loop;
    drop TABLE IF EXISTS programperiodids;
    if _periodid=0 and _facilityid=0 THEN
        return NEW;
    end if;
    drop TABLE IF EXISTS programperiodids;
    
    --verifier program et period de commande
    select into rescheck verifierprogperiodvalide(_programid,_periodid);
    if rescheck!=true THEN
        --raise log  'Is not a command period!';
        return NEW;
    end if;
    rescheck:=false;
    -- select (count(*)>0)::boolean into rescheck from directives_calculs 
    DROP TABLE IF EXISTS temp_directives;
    create temp TABLE temp_directives
    (
        periods2process VARCHAR (50),
        facteur real
    );
    insert into temp_directives select periods2process,facteur from directives_calculs 
    where periodid=_periodid  and productcode=NEW.productcode and programid=_programid; 
    --raise log  '-------- period_id=%,productcode=% and programid=% ------------',_periodid,NEW.productcode,_programid;
    select (count(*)>0)::boolean into rescheck from temp_directives;
    if rescheck != true THEN
        raise log  'No existing directive';
         drop TABLE IF EXISTS temp_directives;
        sumqty:=sumqty+SPLIT_PART(replace( trim (BOTH ']' from  trim(BOTH '[' from NEW.previousnormalizedconsumptions)),' ',''),',',1)::integer;
        sumqty:=sumqty+SPLIT_PART(replace( trim (BOTH ']' from  trim(BOTH '[' from   NEW.previousnormalizedconsumptions)),' ',''),',',2)::integer;
        sumqty:=sumqty+NEW.quantitydispensed;
        correctionfactor:=nbdaysinquater/(nbdaysinquater-NEW.stockoutdays)::float;
        calculatedamc:=round((sumqty/3)*correctionfactor);
        
        ajustedquantitytoorder:= round(((5*calculatedamc)-NEW.stockinhand)::float/NEW.packsize)*NEW.packsize;
        if ajustedquantitytoorder >= 0 THEN
            NEW.quantityrequested:=ajustedquantitytoorder;
        end if ;
        raise log '********************* product=%: old quantity =% and Adjusted quantity=% *******************',NEW.productcode,NEW.calculatedorderquantity,
        NEW.quantityrequested;
        --raise log  'sum quantity ! %',sumqty;
        --raise '######### Execption ##########';
        return NEW;
    ELSE
        raise log  '****** Directive exist on % ******',NEW.productcode;
        resrow:=null;
        for  resrow in  EXECUTE 'select periods2process,facteur from temp_directives' loop
            _periods2process :=resrow.periods2process;
            _factor :=resrow.facteur;
        end loop;
        drop TABLE IF EXISTS temp_directives;
        resrow:=null;
        querystatement:=format ('SELECT  facilityid,
            case when quantitydispensed is not null then quantitydispensed 
            else 0 end as _quantitydispensed
            from vw_searchprevconsumption where  productcode=%s and facilityid=%s and periodid in ( %s )',
            quote_literal(NEW.productcode),_facilityid,_periods2process);
        --raise log 'query  ===> %',querystatement;
        --raise log '        ';
        sumqty:=0;
        for  resrow in  EXECUTE querystatement loop

            sumqty:=sumqty+resrow._quantitydispensed;
            correctionfactor:=nbdaysinquater/(nbdaysinquater-NEW.stockoutdays)::float;
            calculatedamc:=round((sumqty/3)*correctionfactor);
            ajustedquantitytoorder:= ((5*calculatedamc)-NEW.stockinhand)*_factor;
            ajustedquantitytoorder:= round(ajustedquantitytoorder::float/NEW.packsize)*NEW.packsize;
            if ajustedquantitytoorder >= 0 THEN
                NEW.quantityrequested:=ajustedquantitytoorder;
             end if ;
        end loop;
        raise log 'xxxxxxxxxxxx New quantity requested % xxxxxxxxxxxxxxx',NEW.quantityrequested;
        return NEW;
    end if;
    
END
$$;

alter function updatecalculatedquantity() owner to postgres;

