create function fn_get_supplying_facility_name(v_supervisorynode_id integer) returns character varying
    language plpgsql
as
$$
DECLARE
v_supplying_facility_id integer;
v_supplying_facility_name facilities.name%TYPE;
BEGIN
select supplyingfacilityid into v_supplying_facility_id from supply_lines where supervisorynodeid = v_supervisorynode_id;
select name into v_supplying_facility_name from facilities where id =  v_supplying_facility_id;
v_supplying_facility_name = coalesce(v_supplying_facility_name, 'Unknown');
return v_supplying_facility_name;
END;
$$;

alter function fn_get_supplying_facility_name(integer) owner to postgres;

