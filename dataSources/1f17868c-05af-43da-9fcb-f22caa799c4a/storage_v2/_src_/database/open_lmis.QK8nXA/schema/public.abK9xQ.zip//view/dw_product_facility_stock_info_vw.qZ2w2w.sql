create view dw_product_facility_stock_info_vw
            (requisitiongroupid, programid, periodid, geographiczoneid, geographiczonename, facilityid, facilityname,
             facilitycode, productid, primaryname, amc, soh, mos, status, stocking)
as
SELECT 0                             AS requisitiongroupid,
       vw_stock_status_2.programid,
       vw_stock_status_2.periodid,
       vw_stock_status_2.gz_id       AS geographiczoneid,
       vw_stock_status_2.location    AS geographiczonename,
       vw_stock_status_2.facility_id AS facilityid,
       vw_stock_status_2.facility    AS facilityname,
       vw_stock_status_2.facilitycode,
       vw_stock_status_2.productid,
       vw_stock_status_2.product     AS primaryname,
       vw_stock_status_2.amc,
       vw_stock_status_2.stockinhand AS soh,
       vw_stock_status_2.mos,
       vw_stock_status_2.status,
       CASE vw_stock_status_2.status
           WHEN 'SP'::text THEN 'A'::text
           WHEN 'OS'::text THEN 'O'::text
           WHEN 'US'::text THEN 'U'::text
           WHEN 'SO'::text THEN 'S'::text
           ELSE NULL::text
           END                       AS stocking
FROM vw_stock_status_2
ORDER BY vw_stock_status_2.gz_id, vw_stock_status_2.programid, vw_stock_status_2.periodid, vw_stock_status_2.productid,
         vw_stock_status_2.product, vw_stock_status_2.status;

alter table dw_product_facility_stock_info_vw
    owner to postgres;

