create materialized view vw_last_processingorder_periods as
SELECT processing_periods.id
FROM processing_periods
WHERE processing_periods.isorderperiod = true
ORDER BY processing_periods.id DESC
LIMIT 3;

alter materialized view vw_last_processingorder_periods owner to postgres;

create unique index idx_lastprocessingperiod
    on vw_last_processingorder_periods (id);

