create view vw_rnr_status_details
            (programname, programid, periodid, periodname, createddate, facilitycode, facilityname, facilityid, rnrid,
             status, facilitytypename, geographiczoneid, geographiczonename)
as
SELECT p.name  AS programname,
       r.programid,
       r.periodid,
       ps.name AS periodname,
       r.createddate,
       f.code  AS facilitycode,
       f.name  AS facilityname,
       f.id    AS facilityid,
       r.id    AS rnrid,
       r.status,
       ft.name AS facilitytypename,
       gz.id   AS geographiczoneid,
       gz.name AS geographiczonename
FROM facilities f
         JOIN requisitions r ON r.facilityid = f.id
         JOIN programs p ON p.id = r.programid
         JOIN processing_periods ps ON ps.id = r.periodid
         JOIN requisition_status_changes ON r.id = requisition_status_changes.rnrid
         JOIN facility_types ft ON ft.id = f.typeid
         JOIN geographic_zones gz ON gz.id = f.geographiczoneid;

alter table vw_rnr_status_details
    owner to postgres;

