create function fn_get_vaccine_program_id() returns integer
    language plpgsql
as
$$
DECLARE
v_ret integer;
BEGIN
select id into v_ret from programs p where p.enableivdform = true;
v_ret =  COALESCE(v_ret,0);
return v_ret;
END;
$$;

alter function fn_get_vaccine_program_id() owner to postgres;

