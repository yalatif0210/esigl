create view vw_user_districts(user_id, district_id, program_id) as
SELECT DISTINCT vw_user_facilities.user_id,
                vw_user_facilities.district_id,
                vw_user_facilities.program_id
FROM vw_user_facilities;

alter table vw_user_districts
    owner to postgres;

