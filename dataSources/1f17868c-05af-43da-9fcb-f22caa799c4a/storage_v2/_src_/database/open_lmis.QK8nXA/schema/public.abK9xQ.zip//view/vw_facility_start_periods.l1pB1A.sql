create view vw_facility_start_periods(facilityid, geographiczoneid, startdate, programid) as
SELECT DISTINCT f.id               AS facilityid,
                f.geographiczoneid,
                ps.startdate::date AS startdate,
                ps.programid
FROM facilities f
         JOIN requisition_group_members rgm ON f.id = rgm.facilityid
         JOIN programs_supported ps ON ps.facilityid = f.id
         JOIN facility_types ft ON ft.id = f.typeid
WHERE f.active = true;

alter table vw_facility_start_periods
    owner to postgres;

