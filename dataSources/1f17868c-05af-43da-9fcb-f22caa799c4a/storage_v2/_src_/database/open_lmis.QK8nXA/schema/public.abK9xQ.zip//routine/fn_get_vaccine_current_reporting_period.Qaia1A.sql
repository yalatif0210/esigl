create function fn_get_vaccine_current_reporting_period() returns integer
    language plpgsql
as
$$
DECLARE
v_cutoff_days integer;
v_start_date date;
v_end_date date;
v_days_in_month integer;
v_period_id integer;
BEGIN
v_period_id = 0;
select value into v_cutoff_days from configuration_settings where key = 'VACCINE_LATE_REPORTING_DAYS';
if v_cutoff_days::int > 0 then
SELECT
DATE_PART('days',
DATE_TRUNC('month', NOW())
+ '1 MONTH'::INTERVAL
- DATE_TRUNC('month', NOW())
) into v_days_in_month;
if v_cutoff_days > v_days_in_month then
v_cutoff_days = v_days_in_month;
end if;
select
case when (now()::date  - date_trunc('month', current_date)::date)  >= v_cutoff_days
then (date_trunc('month', current_date) - interval '1 month')::date
else (date_trunc('month', current_date) - interval '2 month')::date end into v_start_date;
v_end_date = ( v_start_date + interval '1 month' - interval '1 day')::date;
select id into v_period_id from processing_periods where startdate::date = v_start_date and enddate::date = v_end_date;
v_period_id = COALESCE(v_period_id,0);
end if;
return v_period_id;
END;
$$;

alter function fn_get_vaccine_current_reporting_period() owner to postgres;

