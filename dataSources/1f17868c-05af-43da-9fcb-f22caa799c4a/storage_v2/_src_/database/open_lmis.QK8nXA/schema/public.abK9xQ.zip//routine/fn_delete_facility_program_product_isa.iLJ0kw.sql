create function fn_delete_facility_program_product_isa(program_product_id integer, facility_id integer, delete_facility_pro_prod_mapping boolean) returns void
    language plpgsql
as
$$
DECLARE
isa_coefficient_id integer;
BEGIN
SELECT INTO isa_coefficient_id ic.id
FROM facility_program_products fpp JOIN isa_coefficients ic
ON fpp.isaCoefficientsId = ic.id
WHERE fpp.facilityid = facility_id AND fpp.programproductid = program_product_id;
IF delete_facility_pro_prod_mapping THEN
DELETE FROM facility_program_products
WHERE facilityid = facility_id AND programproductid = program_product_id;
ELSE
UPDATE facility_program_products
SET isaCoefficientsId = NULL
WHERE facilityid = facility_id AND programproductid = program_product_id;
END IF;
DELETE FROM isa_coefficients
WHERE id = isa_coefficient_id;
END;
$$;

alter function fn_delete_facility_program_product_isa(integer, integer, boolean) owner to postgres;

