create view vw_cce_repair_management_not_functional
            (facilityid, fid, programid, model, operationalstatus, modifieddate, modifiedby, facilityname, isbad,
             notfunctionalstatuscount)
as
SELECT notfunctional.facilityid,
       notfunctional.facilityid                                                                   AS fid,
       notfunctional.pid                                                                          AS programid,
       notfunctional.model,
       notfunctional.name                                                                         AS operationalstatus,
       notfunctional.modifieddate,
       notfunctional.modifiedby,
       notfunctional.fname                                                                        AS facilityname,
       notfunctional.isbad,
       count(1)
       OVER (PARTITION BY notfunctional.notfunctionalstatusid, notfunctional.facilityid)          AS notfunctionalstatuscount
FROM (SELECT DISTINCT ON (eis.inventoryid) eis.inventoryid,
                                           eis.notfunctionalstatusid,
                                           eos.name     AS status,
                                           eosnf.name,
                                           eosnf.isbad,
                                           ei.facilityid,
                                           f.name       AS fname,
                                           ei.programid AS pid,
                                           e.model,
                                           ei.modifieddate,
                                           ei.modifiedby
      FROM equipment_inventory_statuses eis
               LEFT JOIN equipment_operational_status eosnf ON eosnf.id = eis.notfunctionalstatusid
               LEFT JOIN equipment_operational_status eos ON eos.id = eis.statusid
               LEFT JOIN equipment_inventories ei ON ei.id = eis.inventoryid
               JOIN equipments e ON ei.equipmentid = e.id
               JOIN equipment_types et ON e.equipmenttypeid = et.id
               JOIN facilities f ON f.id = ei.facilityid
      WHERE et.iscoldchain IS TRUE
      ORDER BY eis.inventoryid, eis.createddate DESC) notfunctional
WHERE notfunctional.name IS NOT NULL;

alter table vw_cce_repair_management_not_functional
    owner to postgres;

