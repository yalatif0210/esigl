create function fn_vaccine_facility_nth_rnr(in_program_id integer, in_period_id integer, in_facility_id integer, in_productid integer, in_nth integer DEFAULT 0)
    returns TABLE(reportid integer, productcode character varying, openingbalance integer, quantityreceived integer, quantityissued integer, quantityvvmalerted integer, quantityfreezed integer, quantityexpired integer, quantitydiscardedunopened integer, quantitydiscardedopened integer, quantitywastedother integer, endingbalance integer, closingbalance integer, daysstockedout integer, price numeric, periodid integer)
    language plpgsql
as
$$
DECLARE
v_rnr_id integer;
finalQuery            VARCHAR;
i integer;
t_period_id integer;
t_start_date date;
t_id integer; -- temp
t_date date; -- temp2
t_price numeric(20,2);
t_product_id integer;
t_quantity_expired integer = 0;
t_li_id integer;
BEGIN
t_product_id = in_productid;
select currentprice into t_price from program_products where productid = t_product_id and programid = in_program_id;
t_start_date = (select startdate::date from processing_periods where id = in_period_id);
t_period_id = COALESCE(in_period_id,0);
i := 0;
FOR i in 1..in_nth
LOOP
i = i+1;
select vaccine_reports.periodid, processing_periods.startdate::date into t_id, t_date
from vaccine_reports
join processing_periods ON vaccine_reports.periodid = processing_periods.id
where processing_periods.startdate < t_start_date
and facilityid = in_facility_id
and vaccine_reports.programid = in_program_id
order by processing_periods.startdate desc
limit 1;
t_start_date = t_date;
t_period_id = COALESCE(t_id,0);
EXIT WHEN t_period_id =  0;
END LOOP;
if t_period_id > 0 then
select id into v_rnr_id
from vaccine_reports
where vaccine_reports.periodid = t_period_id
and facilityid = in_facility_id
and vaccine_reports.programid = in_program_id
order by vaccine_reports.periodid desc
limit 1;
v_rnr_id = COALESCE(v_rnr_id,0);
finalQuery :=
'select
reportid,
productcode,
openingbalance,
quantityreceived,
quantityissued,
quantityvvmalerted,
quantityfreezed,
quantityexpired,
quantitydiscardedunopened,
quantitydiscardedopened,
quantitywastedother,
closingbalance endingbalance,
closingbalance,
daysstockedout,'
||t_price|| ' price, '|| t_period_id || ' periodid '||'
from vaccine_report_logistics_line_items where reportid = '||v_rnr_id || ' and productid = '||in_productid;
ELSE
finalQuery :=
'select
null::int reportid,
null::character varying productcode,
null::int openingbalance,
null::int quantityreceived,
null::int quantityissued,
null::int quantityvvmalerted,
null::int quantityfreezed,
null::int quantityexpired,
null::int quantitydiscardedunopened,
null::int quantitydiscardedopened,
null::int quantitywastedother,
null::int endingbalance,
null::int closingbalance,
null::int daysstockedout,
null::numeric price,
null::integer periodid';
end if;
RETURN QUERY EXECUTE finalQuery;
END;
$$;

alter function fn_vaccine_facility_nth_rnr(integer, integer, integer, integer, integer) owner to postgres;

