create function fn_get_geozonetree_names() returns SETOF geozonetree_names_type
    language plpgsql
as
$$
DECLARE
idVal integer;
zoneVal varchar[];
gnt geozonetree_names_type;
BEGIN
FOR idVal IN (SELECT id FROM geographic_zones WHERE levelid = (SELECT MAX(levelnumber) FROM geographic_levels)) LOOP
SELECT * INTO zoneVal FROM fn_get_geozonetree_names(idVal);
gnt.hierarchy = zoneVal;
gnt.leafid = idVal;
RETURN NEXT gnt;
END LOOP;
END;
$$;

alter function fn_get_geozonetree_names() owner to postgres;

