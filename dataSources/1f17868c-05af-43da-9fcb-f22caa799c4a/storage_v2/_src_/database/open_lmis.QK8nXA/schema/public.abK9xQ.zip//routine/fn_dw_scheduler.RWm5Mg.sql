create function fn_dw_scheduler() returns character varying
    language plpgsql
as
$$
DECLARE msg character varying(2000);
BEGIN
msg := 'Procedure completed successfully.';
delete from alert_summary;
select fn_populate_alert_facility_stockedout();
select fn_populate_alert_requisition_approved();
select fn_populate_alert_requisition_pending();
select fn_populate_alert_requisition_rejected();
select fn_populate_alert_requisition_emergency();
RETURN msg;
EXCEPTION WHEN OTHERS THEN
return SQLERRM;
END;
$$;

alter function fn_dw_scheduler() owner to postgres;

