create view vw_vaccine_target_population
            (year, program_id, facility_id, geographic_zone_id, category_id, category_name, target_value_annual,
             target_value_monthly)
as
SELECT e.year,
       e.programid                             AS program_id,
       e.facilityid                            AS facility_id,
       f.geographiczoneid                      AS geographic_zone_id,
       c.id                                    AS category_id,
       c.name                                  AS category_name,
       e.value                                 AS target_value_annual,
       round((e.value / 12)::double precision) AS target_value_monthly
FROM demographic_estimate_categories c
         LEFT JOIN facility_demographic_estimates e ON c.id = e.demographicestimateid
         JOIN facilities f ON e.facilityid = f.id;

alter table vw_vaccine_target_population
    owner to postgres;

