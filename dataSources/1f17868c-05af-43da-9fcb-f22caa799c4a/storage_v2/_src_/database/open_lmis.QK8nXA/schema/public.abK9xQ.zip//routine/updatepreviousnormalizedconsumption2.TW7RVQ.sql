create function updatepreviousnormalizedconsumption2() returns trigger
    language plpgsql
as
$fun$
DECLARE
resultops integer :=null;
listperiodseparator constant char :=',';
periodsourcemin int :=null;
periodsourcemax int :=null;
reqlineitemtoupdate int :=null;
querystatement VARCHAR;
resrow record;
rescheck BOOLEAN :=false;
_programid int :=0;
_periodid int :=0;
_facilityid int :=0;
listperiodsource  varchar :=null;
iterate int :=0;

BEGIN

--raise   '******** Exception *************';
resrow:=null;
DROP TABLE IF EXISTS programperiodids;
create temp TABLE programperiodids
(
    programid int,
    periodid int,
    facilityid int

);
insert into programperiodids
select programid ,periodid,facilityid from requisitions where id=NEW.rnrid and programid=1;

for  resrow in  EXECUTE 'select * from programperiodids ' loop
 --raise log  'program id = % and %',resrow.programid,resrow.periodid;
    _programid:=resrow.programid;
    _periodid:=resrow.periodid;
    _facilityid=resrow.facilityid;
end loop;
if _periodid=0 and _facilityid=0 THEN
    return NEW;
end if;
--Get the twe last processing_periods to use for prevconsumptions
for  resrow in  EXECUTE 'select id from vw_last_processing_periods order by id desc limit 2 offset 1' loop
    case 
        when iterate=0 then listperiodsource:= concat(resrow.id,',') ;
        else listperiodsource:=concat(listperiodsource,resrow.id);
        end case;
    iterate:= iterate+1;
end loop;
raise log 'listperiodsource %',listperiodsource;
 drop TABLE IF EXISTS programperiodids;
--verifier program et period de commande
select into rescheck verifierprogperiodvalide(_programid,_periodid);
if rescheck!=true THEN
    --raise log  'Is not a command period!';
    return NEW;
end if;

 raise log  'Command period confirmed';

/*select (count(*)>0)::boolean into rescheck from directives_calculs 
where periodid=_periodid  and productcode=NEW.productcode and programid=_programid;*/
if true THEN
    --raise log  'No existing directive';
    periodsourcemin:=SPLIT_PART(listperiodsource,',',1)::integer;
    periodsourcemax:=SPLIT_PART(listperiodsource,',',2)::integer;

    raise log 'step 3 OK. periodsourcemin = % and periodsourcemin=%',periodsourcemin,periodsourcemax;

    querystatement:=format ('select 
    facilityid,
    case WHEN period_next is not null and period_prev is not null THEN concat(''['',period_prev,'', '', period_next,'']'') 
    WHEN period_next is not null THEN concat(''['',period_next,'', '',period_next,'']'')  
    WHEN period_prev is not null THEN concat(''['',period_prev,'', '',period_prev,'']'') 
    else ''[]'' end as prevconsumptions
    from crosstab (
    $$
    SELECT  facilityid,case when periodid=%s then ''period_prev'' else ''period_next'' end as period,
    quantitydispensed
    from vw_searchprevconsumption 
    where periodid  in (%s,%s)
    and productcode=%s and facilityid=%s
    order by  facilityid, period
    $$
    ) as subq  (facilityid int, period_prev int,period_next int) order by facilityid',periodsourcemin,periodsourcemin,
    periodsourcemax,quote_literal(NEW.productcode),_facilityid);
    
    for  resrow in  EXECUTE querystatement loop
        --raise log '************ query= % *********************',resrow.prevconsumptions;
        NEW.previousnormalizedconsumptions=resrow.prevconsumptions;
    end loop;
    return NEW;
ELSE
    return NEW;
end if;
--raise   'Exception ';

END
$fun$;

alter function updatepreviousnormalizedconsumption2() owner to postgres;

