create function fn_insert_isa(whoratio numeric, dosesperyear integer, wastagefactor numeric, bufferpercentage numeric, minimumvalue integer, maximumvalue integer, adjustmentvalue integer, createdby integer, createddate timestamp without time zone, modifiedby integer, modifieddate timestamp without time zone, populationsource integer, program_product_id integer, facility_id integer DEFAULT '-1'::integer) returns integer
    language plpgsql
as
$$
DECLARE
orig_isa_id integer;
fac_prog_prod_id integer;
isa_coefficient_id integer;
BEGIN
INSERT INTO isa_coefficients(whoratio, dosesperyear, wastagefactor, bufferpercentage, minimumvalue, maximumvalue, adjustmentvalue, createdby, createddate, modifiedby, modifieddate, populationsource)
VALUES(whoratio, dosesperyear, wastagefactor, bufferpercentage, minimumvalue, maximumvalue, adjustmentvalue, createdby, createddate, modifiedby, modifieddate, populationsource)
RETURNING id INTO isa_coefficient_id;
IF facility_id < 0 THEN
UPDATE program_products
SET isaCoefficientsId = isa_coefficient_id
WHERE id = program_product_id;
ELSE
SELECT id INTO fac_prog_prod_id FROM facility_program_products
WHERE programproductid = program_product_id
AND facilityid = facility_id;
SELECT ic.id INTO orig_isa_id
FROM isa_coefficients ic JOIN facility_program_products fpp
ON fpp.isaCoefficientsId = ic.id
WHERE fpp.id = fac_prog_prod_id;
DELETE FROM facility_program_products
WHERE id = fac_prog_prod_id;
DELETE FROM isa_coefficients WHERE id = orig_isa_id;
INSERT INTO facility_program_products(facilityId, programProductId, isaCoefficientsId)
VALUES(facility_id, program_product_id, isa_coefficient_id);
END IF;
return isa_coefficient_id;
END;
$$;

alter function fn_insert_isa(numeric, integer, numeric, numeric, integer, integer, integer, integer, timestamp, integer, timestamp, integer, integer, integer) owner to postgres;

